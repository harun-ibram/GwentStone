package org.poo.actions;

public interface ExecuteAction {

    /**
     * Executes the current card's ability
     */
    void executeAction();
}
