package org.poo.cards;

import org.poo.fileio.CardInput;

public final class Sentinel extends Minion {

    public Sentinel(final CardInput card) {
        super(card);
    }
}
