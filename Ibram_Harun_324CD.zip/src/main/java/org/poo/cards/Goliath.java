package org.poo.cards;

import org.poo.fileio.CardInput;

public final class Goliath extends Minion {

    public Goliath(final CardInput card) {
        super(card);
    }
}
